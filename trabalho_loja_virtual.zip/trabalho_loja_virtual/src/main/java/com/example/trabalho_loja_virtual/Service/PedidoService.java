package com.example.trabalho_loja_virtual.Service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.trabalho_loja_virtual.entities.Item_Pedido;
import com.example.trabalho_loja_virtual.entities.Pedidos;
import com.example.trabalho_loja_virtual.entities.Produto;
import com.example.trabalho_loja_virtual.repository.ItemPedidoRepository;
import com.example.trabalho_loja_virtual.repository.PedidoRepository;
import com.example.trabalho_loja_virtual.repository.ProdutosRepository;

@Service
public class PedidoService {
    @Autowired
    private ItemPedidoRepository itemPedidoRepository;
    
    @Autowired
    private PedidoRepository pedidoRepository;
    
    @Autowired
    private ProdutosRepository produtosRepository;
    
    public boolean adicionarItemAoPedido(Long pedidoId, Long produtoId, int quantidade) {
        Pedidos pedido = pedidoRepository.findById(pedidoId).orElseThrow();
        Produto produto = produtosRepository.findById(produtoId).orElseThrow();
        
        if (produto.getEstoque() >= quantidade) {
            produto.setEstoque(produto.getEstoque() - quantidade);
            produtosRepository.save(produto);
            
            Item_Pedido itemPedido = new Item_Pedido();
            itemPedido.setPedido(pedido);
            itemPedido.setProduto(produto);
            itemPedido.setQuantidade(quantidade);
            itemPedido.setValorTotal(produto.getPreco().multiply(BigDecimal.valueOf(quantidade)));
            
            itemPedidoRepository.save(itemPedido);
            pedido.setValor(pedido.getValor().add(itemPedido.getValorTotal()));
            pedidoRepository.save(pedido);
            return true;
        }else {
            return false;
        }
        
    }
    
    public boolean apagarItemDoPedido(Long itemPedidoId, long pedidoId) {
        Item_Pedido itemPedido = itemPedidoRepository.findById(itemPedidoId).orElseThrow();
        Produto produto = itemPedido.getProduto();
        
        produto.setEstoque(produto.getEstoque() + itemPedido.getQuantidade());
        produtosRepository.save(produto);
        
        Pedidos p = pedidoRepository.findById(pedidoId).orElseThrow();
        p.setValor(p.getValor().subtract(itemPedido.getValorTotal()));
        pedidoRepository.save(p);
        itemPedidoRepository.delete(itemPedido);
        return true;
    }
}
    