package com.example.trabalho_loja_virtual.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.trabalho_loja_virtual.entities.Cliente;
import com.example.trabalho_loja_virtual.entities.Lojista;
import com.example.trabalho_loja_virtual.entities.User;
import com.example.trabalho_loja_virtual.enums.Tipo_User;
import com.example.trabalho_loja_virtual.repository.ClienteRepository;
import com.example.trabalho_loja_virtual.repository.LojistaRepository;
import com.example.trabalho_loja_virtual.repository.UserRepository;

@Service
public class UserService {
    @Autowired
        private UserRepository userRepository;

    @Autowired
        private PasswordEncoder PE;

    @Autowired
        private ClienteRepository clienteRepository;

    @Autowired
        private LojistaRepository lojistaRepository;

    public String criptografarSenha(String senha) {
        String hsenha = PE.encode(senha);
        return hsenha; // Retorna a senha criptografada (substitua pela lógica real)
    }

    public boolean conferirSenha(String senhaDigitada, String senhaArmazenada) {
        return PE.matches(senhaDigitada, senhaArmazenada);
    }

    public boolean validarEmail(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    public boolean validarSenha(String senha) {
        // Implementar lógica de validação de senha (ex: mínimo 8 caracteres, etc.)
        return senha.length() >= 8; // Exemplo simples de validação
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }

    public User insert(User user) {
        user.setSenha(criptografarSenha(user.getSenha()));
        userRepository.save(user);
        salvarUserTipo(user);
        return user;
    }

    public List<User> selectAll(){
        List<User> us = userRepository.findAll();
        return us;
    }

    public boolean salvarUserTipo(User u){
        if(u.getTipoUser() == Tipo_User.lOJISTA){
            Lojista l= new Lojista();
            l.setUser(u);
            lojistaRepository.save(l);
            return true;
        }
        if(u.getTipoUser() == Tipo_User.CLIENTE){
            Cliente c= new Cliente();
            c.setUser(u);
            clienteRepository.save(c);
            return true;
        }
        else{
            System.out.println("tipo de usuario n cadastrado!!!");
            return false;
        }
    }
}
