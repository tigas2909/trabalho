package com.example.trabalho_loja_virtual.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.trabalho_loja_virtual.entities.Cliente;

public interface ClienteRepository extends JpaRepository< Cliente , Long>{

}
