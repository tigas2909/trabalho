package com.example.trabalho_loja_virtual.Controller;

import com.example.trabalho_loja_virtual.Service.PedidoService;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.trabalho_loja_virtual.Service.UserService;
import com.example.trabalho_loja_virtual.entities.Item_Pedido;
import com.example.trabalho_loja_virtual.entities.Pedidos;
import com.example.trabalho_loja_virtual.entities.Produto;
import com.example.trabalho_loja_virtual.entities.User;
import com.example.trabalho_loja_virtual.enums.Tipo;
import com.example.trabalho_loja_virtual.repository.ItemPedidoRepository;
import com.example.trabalho_loja_virtual.repository.PedidoRepository;
import com.example.trabalho_loja_virtual.repository.ProdutosRepository;
import com.example.trabalho_loja_virtual.repository.UserRepository;

@Controller
@RequestMapping("/lojista")
public class LojistaController {

    @Autowired
    private UserService UserService;
    
    @Autowired
    private ProdutosRepository produtosRepository;

    @Autowired
    private UserRepository UserRepository;

    @Autowired 
    private PedidoRepository PedidoRepository;

    @Autowired
    private ItemPedidoRepository itemPedidoRepository;
    
    @Autowired
    private PedidoService pedidoService;

    @GetMapping("/{email}")
    public String dashboard(@PathVariable String email, Model model) {
        System.out.println("EMAIL RECEBIDO: " + email);
        User user = UserService.getUserByEmail(email);
        System.out.println("USER: " + user);
        model.addAttribute("nome", user.getNome());
        return "/lojista/lojistaPagPrin";
    }

    //ADICIONAR USER
    @GetMapping("/add")
    public String add() {
        return "lojista/userForm";
    }

    @PostMapping("/save")
    public String save(User user) {
        UserService.insert(user);
        return "redirect:/login/logout";
    }

    //ESTOQUE

    @GetMapping("/dashboard")
    public String dashboard(
        @CookieValue(value = "userId", required = false) Long userId,
        Model model) {
            
        if (userId == null) {
            return "redirect:/login";
        }

        User user = UserRepository.findById(userId)
                .orElse(null);

        if (user == null) {
            return "redirect:/login";
        }

        // 1. Estoque baixo
        List<Produto> estoqueBaixo =
                produtosRepository.findProdutosComEstoqueBaixo();

        // 2. Mais vendidos
        List<Object[]> maisVendidos =
                produtosRepository.findProdutosMaisVendidos();

        // 3. Estoque total
        Integer estoqueTotal = produtosRepository
                .findAll()
                .stream()
                .mapToInt(Produto::getEstoque)
                .sum();

        // 👇 dados da tela
        model.addAttribute("nome", user.getNome());
        model.addAttribute("estoqueBaixo", estoqueBaixo);
        model.addAttribute("maisVendidos", maisVendidos);
        model.addAttribute("estoqueTotal", estoqueTotal);

        return "lojista/estoque";
    }

    //ATUALIZAR STATUS DO PRODUTO
    @GetMapping("/estoque")
    public String listarProdutos(Model model) {
        model.addAttribute("produtos", produtosRepository.findAll());
        return "lojista/dashboard";
    }

    @PostMapping("/trocar-status/{id}")
    public String trocarStatus(@PathVariable Long id) {

        Produto produto = produtosRepository.findById(id).orElseThrow();

        if (produto.getStatus() == Tipo.ATIVO) {
            produto.setStatus(Tipo.INATIVO);
        } else {
            produto.setStatus(Tipo.ATIVO);
        }

        produtosRepository.save(produto);

        return "redirect:/lojista/estoque";
    }

    //pedidos

    @GetMapping("/pedidos")
    public String listarPedidos(Model model) {
        model.addAttribute("pedidos", PedidoRepository.findAll());
        return "lojista/pedidos";
    }

    @GetMapping("/pedidos/{id}/editar")
    public String editarPedido(@PathVariable Long id, Model model) {
        model.addAttribute("pedido", PedidoRepository.findById(id).orElseThrow());
        model.addAttribute("produtos", produtosRepository.findAll());
        return "lojista/editarPedido";
    }

    @PostMapping("/pedidos/{id}/adicionar-item")
    public String adicionarItem(@PathVariable Long id,
                                @RequestParam Long produtoId,
                                @RequestParam int quantidade,
                                Model model) {
        boolean result = pedidoService.adicionarItemAoPedido(id, produtoId, quantidade);
        if (!result) {
            System.out.println("Erro ao adicionar item ao pedido");
        }

        return "redirect:/lojista/pedidos/" + id + "/editar";
    }

    @PostMapping("/pedidos/{id}/remover-item/{itemId}")
    public String removerItem(@PathVariable Long id, @PathVariable Long itemId) {
        boolean result = pedidoService.apagarItemDoPedido(itemId, id);
        if (!result) {
            System.out.println("Erro ao remover item do pedido");
        }
        
        return "redirect:/lojista/pedidos/" + id + "/editar";
    }

    //USUARIO ATUALIZAR USER
}
