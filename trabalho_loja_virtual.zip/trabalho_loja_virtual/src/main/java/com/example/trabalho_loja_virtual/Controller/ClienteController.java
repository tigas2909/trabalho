package com.example.trabalho_loja_virtual.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.trabalho_loja_virtual.Service.UserService;
import com.example.trabalho_loja_virtual.entities.User;


@Controller
@RequestMapping("/cliente")
public class ClienteController {
    @Autowired
    private UserService US;

    @GetMapping("/{email:.+}")
    public String paginaInicial(@PathVariable String email, Model model) {

        User user = US.getUserByEmail(email);

        model.addAttribute("nome", user.getNome());

        return "user/paginaInicial";
    }   

    
}
