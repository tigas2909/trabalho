package com.example.trabalho_loja_virtual.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.trabalho_loja_virtual.Service.ProdutoService;
import com.example.trabalho_loja_virtual.Service.UserService;
import com.example.trabalho_loja_virtual.entities.Produto;
import com.example.trabalho_loja_virtual.entities.User;


@Controller
@RequestMapping("/cliente")
public class ClienteController {
    @Autowired
    private UserService US;

    @Autowired
    private ProdutoService PS;

    @GetMapping("/{email:.+}")
    public String paginaInicial(@PathVariable String email, Model model) {

        User user = US.getUserByEmail(email);

        model.addAttribute("nome", user.getNome());

        return "user/paginaInicial";
    }   

    @GetMapping("/produtos")
    public String produtosSelect(Model model){
        List<Produto> produtos = PS.listagemCliente();
        model.addAttribute("produtos", produtos);
        return "user/produtos";
    }
    @GetMapping("/produto/{id}")
    public String produto(@PathVariable Long id, Model model ){
        Produto  produto = PS.buscarPorId(id);
        model.addAttribute("produto", produto);

        return "user/produto-detalhe";
    }

    
}
